
public final class ConstantValues {

	//URL of file which holds the User Message
	public static String inputFilePath = "C:\\Users\\Rayyan\\Desktop\\testMessageFile.txt";
	
	//URL of file where Encrypted Message is to be written
	public static String writeFilePath = "C:\\Users\\Rayyan\\Desktop\\testByteFile.txt";
	
	//URL of file which will hold the Encrypted Message
	public static String cipherFilePath = "C:\\Users\\Rayyan\\Desktop\\testByteFile.txt";
	
	//URL of file which will hold the Decrypted Message
	public static String writeDecryptedFilePath = "C:\\Users\\Rayyan\\Desktop\\decryptedMessage.txt";
	
	//Encryption Key
	public static String KEY = "privateK";
}
